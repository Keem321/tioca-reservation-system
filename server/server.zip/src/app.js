/**
 * Server Entry Point
 *
 */

import express, { json } from "express";
// must setup sessions when using passport OAuth strategies by default -- it can be done statelessly with more config
import session from "express-session";
import MongoStore from "connect-mongo";

import { connect } from "mongoose";
import fs from "fs";
import path from "path";
import cors from "cors";
import { apiRouter, publicRouter } from "./routes/index.js";
import passport from "passport";
import holdCleanupService from "./services/holdCleanup.service.js";
const app = express();

const PORT = process.env.PORT || 5000;
const MONGO_URI =
	process.env.MONGO_URI || "mongodb://localhost:27017/tioca-reservation-system";

// Middleware
// Allow cross-origin requests from the client and include credentials (cookies)
const clientOrigin = process.env.CLIENT_ORIGIN || "http://localhost:5173";
console.log(`[CORS] Configured with origin: ${clientOrigin}`);

app.use(
	cors({
		origin: clientOrigin,
		credentials: true,
		allowedHeaders: ["Content-Type", "Authorization"],
		exposedHeaders: ["set-cookie"],
		methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
	})
);

app.use(json());

// Trust the entire proxy chain (CloudFront -> ALB -> Nginx) so req.secure is accurate
app.set("trust proxy", true);

// Fix req.secure for CloudFront/ALB proxy chain: detect multi-hop forwarding
// When x-forwarded-for has 2+ IPs, we're behind a proxy chain
// and should treat as secure if CLIENT_ORIGIN is https (override the read-only getter)
app.use((req, res, next) => {
	const xForwardedFor = req.headers["x-forwarded-for"];
	if (xForwardedFor) {
		const hopCount = xForwardedFor.split(",").length;
		if (hopCount >= 2) {
			const isHttpsOrigin = clientOrigin.startsWith("https://");
			if (isHttpsOrigin && !req.secure) {
				// Use Object.defineProperty to override the read-only getter
				// This allows us to fake req.secure=true for express-session cookie logic
				Object.defineProperty(req, "secure", {
					value: true,
					writable: false,
					configurable: true,
				});
				console.log(
					`[Proxy] Detected CloudFront chain (${hopCount} hops), overriding req.secure=true`
				);
			}
		}
	}
	next();
});

// Request logging middleware
app.use((req, res, next) => {
	console.log(
		`[REQUEST] ${req.method} ${req.path} | Origin: ${req.get(
			"origin"
		)} | User-Agent: ${req.get("user-agent")?.substring(0, 50)}`
	);
	next();
});

// Session setup - detect secure mode by checking if CLIENT_ORIGIN is HTTPS
const isSecureEnv = clientOrigin.startsWith("https://");
console.log(`[Session Config] CLIENT_ORIGIN: ${clientOrigin}`);
console.log(`[Session Config] isSecureEnv: ${isSecureEnv}`);
console.log(
	`[Session Config] Cookie settings: secure=${isSecureEnv}, sameSite=${
		isSecureEnv ? "none" : "lax"
	}`
);

const sessionStore = new MongoStore({
	mongoUrl: MONGO_URI,
	touchAfter: 24 * 3600, // lazy session update interval (seconds)
	mongoOptions: {
		// Allow TLS connections without strict certificate validation
		// (required for AWS DocumentDB)
		tls: true,
		tlsAllowInvalidCertificates: true,
	},
});

// Observe session store state
try {
	sessionStore.on?.("connected", () =>
		console.log("[Session Store] connected to Mongo/DocumentDB")
	);
	sessionStore.on?.("disconnected", () =>
		console.warn("[Session Store] disconnected from Mongo/DocumentDB")
	);
	sessionStore.on?.("error", (err) =>
		console.error("[Session Store] error:", err)
	);
} catch (e) {
	console.warn("[Session Store] event listeners unavailable", e?.message);
}

app.use(
	session({
		store: sessionStore,
		secret: process.env.SESSION_SECRET || "tioca-session-secret-2026",
		name: "tioca.sid", // Custom session cookie name
		resave: false,
		saveUninitialized: false, // Only create session when user modifies it
		cookie: {
			secure: isSecureEnv, // https only in production
			sameSite: isSecureEnv ? "none" : "lax", // "none" required for cross-site HTTPS cookies (CloudFront)
			httpOnly: true,
			maxAge: 24 * 60 * 60 * 1000, // 24 hours
		},
	})
);
app.use(passport.initialize());
app.use(passport.session());

// Debug middleware - log session info
app.use((req, res, next) => {
	console.log(
		`[Session] ${req.method} ${req.path} - Session ID: ${req.sessionID}`
	);
	console.log(`[Session] req.session.passport:`, req.session?.passport);
	console.log(
		`[Session] req.user:`,
		req.user ? `User ID ${req.user.id || req.user._id}` : "undefined"
	);
	console.log(`[Session] req.isAuthenticated():`, req.isAuthenticated?.());
	console.log(
		`[Session] secure=${req.secure} x-forwarded-proto=${req.headers["x-forwarded-proto"]}`
	);

	// Log incoming cookie names and forwarding information
	const cookieHeader = req.headers["cookie"];
	if (cookieHeader) {
		const names = cookieHeader
			.split("; ")
			.map((p) => p.split("=")[0])
			.slice(0, 10);
		console.log(`[Cookie] Incoming cookie names:`, names);
	} else {
		console.log(`[Cookie] No Cookie header received`);
	}
	console.log(
		`[Proxy] x-forwarded-for=${req.headers["x-forwarded-for"]} host=${req.headers["host"]}`
	);
	// Log any Set-Cookie on response once it finishes
	res.on("finish", () => {
		const setCookie = res.getHeader("set-cookie");
		if (setCookie) {
			const arr = Array.isArray(setCookie) ? setCookie : [setCookie];
			const summarized = arr.map((c) => {
				const parts = String(c).split("; ");
				const [nameValue, ...attrs] = parts;
				const name = nameValue.split("=")[0];
				const flags = {
					Secure: attrs.some((a) => /^Secure$/i.test(a)),
					HttpOnly: attrs.some((a) => /^HttpOnly$/i.test(a)),
					SameSite:
						attrs.find((a) => /^SameSite=/i.test(a))?.split("=")[1] || null,
					Path: attrs.find((a) => /^Path=/i.test(a))?.split("=")[1] || null,
					Domain: attrs.find((a) => /^Domain=/i.test(a))?.split("=")[1] || null,
					MaxAge:
						attrs.find((a) => /^Max-Age=/i.test(a))?.split("=")[1] || null,
					Expires:
						attrs.find((a) => /^Expires=/i.test(a))?.split("=")[1] || null,
				};
				return { name, ...flags };
			});
			console.log(
				`[Cookie] Set-Cookie on ${req.method} ${req.originalUrl}:`,
				summarized
			);
		}
	});
	next();
});

// Health check endpoint for deployment verification
app.get("/health", (req, res) => {
	res.status(200).json({ status: "ok" });
});

// API resource routes
app.use("/api", apiRouter);
// Public and auth routes
app.use("/", publicRouter);

// DocumentDB/MongoDB connection options
const mongoOptions = {
	// sensible defaults for server selection and socket timeouts
	serverSelectionTimeoutMS: 30000,
	socketTimeoutMS: 45000,
};

const useDocDBTls =
	process.env.DOCDB_TLS === "true" ||
	/ssl=true|tls=true/i.test(MONGO_URI || "");
if (useDocDBTls) {
	mongoOptions.tls = true;
	mongoOptions.retryWrites = false;

	// Use CA bundle committed in repo for AWS DocumentDB TLS
	const caPath = path.resolve("./global-bundle.pem");
	if (fs.existsSync(caPath)) {
		mongoOptions.tlsCAFile = caPath;
		console.log(`Using DocumentDB CA file at ${caPath}`);
	} else {
		console.warn(
			`Expected CA bundle at '${caPath}' but file was not found. TLS trust may fail.`
		);
	}
}

// Try to connect to MongoDB/DocumentDB, but always start server for health check
connect(MONGO_URI, mongoOptions)
	.then(() => {
		console.log("MongoDB connected successfully");

		// Start the hold cleanup service after successful DB connection
		holdCleanupService.start();
	})
	.catch((err) => {
		console.error("MongoDB connection error:", err);
		console.log(
			"Starting server without database connection for health check."
		);
	})
	.finally(() => {
		app.listen(PORT, () => {
			console.log(`Server running on port ${PORT}`);
			console.log(
				`[Startup] trust proxy=${app.get(
					"trust proxy"
				)} clientOrigin=${clientOrigin}`
			);
		});
	});

// Centralized error handler (ensures JSON + logs)
// Note: keep this after all routes
app.use((err, req, res, _next) => {
	console.error(
		`[Error] ${req.method} ${req.originalUrl}:`,
		err?.message,
		err?.stack?.split("\n").slice(0, 3).join(" | ")
	);
	if (!res.headersSent) {
		res
			.status(err.status || 500)
			.json({ message: err.message || "Server error" });
	}
});

// Global error handlers to prevent the server from exiting unexpectedly
process.on("unhandledRejection", (reason, p) => {
	console.error("Unhandled Rejection at:", p, "reason:", reason);
});

process.on("uncaughtException", (err) => {
	console.error("Uncaught Exception:", err);
	// Always log and do not exit
});

// Graceful shutdown handlers
process.on("SIGINT", () => {
	console.log("\nReceived SIGINT, shutting down gracefully...");
	holdCleanupService.stop();
	process.exit(0);
});

process.on("SIGTERM", () => {
	console.log("\nReceived SIGTERM, shutting down gracefully...");
	holdCleanupService.stop();
	process.exit(0);
});

export default app;
